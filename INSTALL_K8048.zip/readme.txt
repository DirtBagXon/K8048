========================================================================================================
 	   	  K8048 & VM111 - PIC(tm) Programmer & Experiment board's 
		    
      K8048 software V2.3.20  ***  Copyright (c) 2003,2004 Velleman Components NV.

            portion copyright (C) 1997 - 2004 Microchip Technology Inc.

========================================================================================================

Thank you for building and using our PIC programmer VM111 or KIT version K8048.

1) Make sure that you have an ASCII text editor on your PC (Notepad,...), 
   Internet Explorer 4.x or higher and Acrobat PDF reader is installed.
   

2) Run the INSTALL_K8048.EXE, self extracting utility
   This will copy all folders and files to your local hard disk drive, default in 
   the C:\VELLEMAN\K8048 folder.

3) Run & config the PICPROG2.EXE programing software.
   Click 'HELP-Topics' to learn how to use your K8048 PIC programmer.
   HELP file is in the \VELLEMAN\K8048 folder, "K8048.CHM"
 


for more information and updates, please visit our website www.velleman.be


Success !

The Velleman team.





-----------------------------------------------------------
   DISCLAIMER : This software is supplied 'as-is'.
   No guarantees are made, no responsabilities are taken.
   Use it at your own risk.
-----------------------------------------------------------


PIC(tm) is a registrated trademark of Microchip Technology Inc. (www.microchip.com)